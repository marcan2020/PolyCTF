Translations may be created with POEdit - http://www.poedit.net/

The base file you open for translations opportunities is rsvpmaker.pot

Translations should be saved with the filename pattern rsvpmaker-[locale].po

Example: rsvpmaker-fr_FR.po for French

POEdit will generate a compiled version with the .mo extension to be used at runtime

Send both files to david@carrcommunications.com to be added to the RSVPMaker distribution

How-To Articles
http://codex.wordpress.org/Translating_WordPress
http://urbangiraffe.com/articles/translating-wordpress-themes-and-plugins/